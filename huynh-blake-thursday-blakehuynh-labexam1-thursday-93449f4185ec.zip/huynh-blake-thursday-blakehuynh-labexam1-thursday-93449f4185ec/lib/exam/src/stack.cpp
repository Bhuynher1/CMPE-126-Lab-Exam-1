#include "../inc/stack.h"

stack::stack() {
    stack_top = 0;
}

stack::~stack() {
    while (stack_top) {
        if (stack_top -> next == nullptr) {
            stack_top = nullptr;
        }
        else {
            stack_node* temp = stack_top -> next;
            delete stack_top;
            stack_top = temp;
        }
    }
}

void stack::pop() {
    stack_node *stack1;
    stack1 = stack_top;
    stack_top = stack_top -> next;
    delete stack1;
}

void stack::push(struct value_date input) {
    stack_node *stack2 = new stack_node(input);

    if (empty()) {
        stack_top = stack2;
    }
    else {
        stack2 -> next = stack_top;
        stack_top = stack2;
    }
}

const struct value_date stack::top() const {
    if (stack_top == 0) {
        throw "Error: Empty stack_top.";
    }
    else {
        stack_node* curr = stack_top;
        while (curr -> next != nullptr) {
            curr = curr -> next;
        }
    }

    return stack_top -> data;
}

bool stack::empty() {
    return stack_top == nullptr;
}

stack &stack::operator=(const stack &RHS) {
    if (this != &RHS) {
        if (stack_top != nullptr) {
            delete this;
            stack_top = RHS.stack_top;
        }
        if (RHS.stack_top != nullptr) {
            stack_node *tempRHS = RHS.stack_top;
            stack_node *temp = stack_top = new stack_node(tempRHS -> data);
            tempRHS = tempRHS -> next;

            while (tempRHS != nullptr) {
                temp -> next = new stack_node(tempRHS -> data);
                temp = temp -> next;
                tempRHS = tempRHS -> next;
            }
        }
        return *this;
    }
}

stack stack::operator+(const stack &RHS) const {
    stack temp;
    stack currentStack = *this;
    stack rightStack = RHS;

    while (rightStack.stack_top != nullptr) {
        value_date mergeDate = rightStack.top();
        rightStack.pop();
        temp.push(mergeDate);
    }

    while (temp.stack_top != nullptr) {
        value_date mergeDate = temp.top();
        temp.top();
        currentStack.push(mergeDate);
    }
    return currentStack;
}
