#include "../inc/inventory.h"

int inventory::reserve_upc() {
    srand(42);
    auto random_upc_location = int(rand()%upc_generator.size());
    auto a = upc_generator.begin();
    for(auto a = upc_generator.begin(); --random_upc_location != 0; a++);
    while(!a->second && a != upc_generator.end()) a++;
    a->second = false;
    return a->first;
}

void inventory::release_upc(int input_upc) {
    auto val =  upc_generator.find(input_upc);
    if(val->first == input_upc && !val->second){
        val->second = true;
        return;
    }
    else throw "UPC not valid";
}

bool inventory::valid_upc(int input_upc) {
    if(input_upc == 0) return false;
    auto val = inventory::upc_generator.find(input_upc);
    return val->first == input_upc;
}

void inventory::initialize_upc() {
    srand(17); // Initial seed
    for(int i = 1; i< 1000; i++) {
        int unique_upc = 1000000 + rand() % 9000000;
        inventory::upc_generator.insert(std::pair<int, bool>(unique_upc, true));
    }
}

inventory::inventory() {
    head = NULL;
    initialize_upc();
}

inventory::~inventory() {
    while (head) {
        if (head -> next == NULL)
            head = nullptr;
        else {
            inventory_node* temp = head -> next;
            delete head;
            head = temp;
        }
    }
}

void inventory::add_sku(std::string new_name, int initial_price, int initial_inventory, int initial_date) {
    int newUPC = reserve_upc();
    while (valid_upc(newUPC) == false) {
        newUPC = reserve_upc();
    }

    inventory_node* temp = new inventory_node (newUPC, new_name, initial_price, initial_inventory, initial_date);
    if (head == nullptr) {
        head = temp;
    }
    else {
        inventory_node* curr = head;
        while (curr -> next != nullptr) {
            curr = curr -> next;
        }
        curr -> next = temp;
        curr = curr -> next;
    }
}

void inventory::remove_sku(int input_upc) {
    if (valid_upc(input_upc) == false) {
        throw "no input upc";
    }
    else if (head -> next == nullptr) {
        head = nullptr;
    }
    else if (head -> upc == input_upc) {
        inventory_node* tail = head -> next;
        delete head;
        head = tail;
    }
    else {
        inventory_node* prev;
        inventory_node* curr = head;
        while (curr -> upc != input_upc) {
            prev = curr;
            curr = curr -> next;
        }

        prev -> next = curr -> next;
        delete curr;
    }
}

std::vector<int> inventory::get_upc(std::string input_name) {
    std::vector<int> upc_num;
    inventory_node* curr = head;
    while (curr != nullptr) {
        if (curr -> name == input_name) {
            upc_num.push_back(curr -> upc);
        }
        curr = curr -> next;
    }
    return upc_num;
}

int inventory::get_price(int input_upc) {
    if (valid_upc(input_upc) == false)
        throw "no input upc";
    else if (head == nullptr)
        throw "no head value";
    else {
        inventory_node* curr = head;
        while (curr -> upc != input_upc) {
            curr = curr -> next;
        }
        return curr -> price.top().value;
    }
}

int inventory::get_inventory(int input_upc) {
    if (valid_upc(input_upc) == false)
        throw "no input upc";
    else if (head == nullptr)
        throw "no head value";
    else {
        inventory_node* curr = head;
        while (curr -> upc != input_upc) {
            curr = curr -> next;
        }
        return curr -> inventory_count;
    }
}

std::string inventory::get_name(int input_upc) {
    if (valid_upc(input_upc) == false)
        throw "no input upc";
    else if (head == nullptr)
        throw "no head value";
    else {
        inventory_node* curr = head;
        while (curr -> upc != input_upc) {
            curr = curr -> next;
        }
        return curr -> name;
    }
}

int inventory::get_lowest_price(int input_upc) {
    if (valid_upc(input_upc) == false)
        throw "no input upc";
    else if (head == nullptr)
        throw "no head value";
    else {
        inventory_node* curr = head;
        while (curr -> upc != input_upc) {
            curr = curr -> next;
        }
        stack find;
        find.operator=(curr -> price);
        int lowPrice = find.top().value;
        find.pop();
        while (find.empty() == false) {
            if (find.top().value < lowPrice)
                lowPrice = find.top().value;
            find.pop();
        }
        return lowPrice;
    }
}

int inventory::get_highest_price(int input_upc) {
    if (valid_upc(input_upc) == false)
        throw "no input upc";
    else if (head == nullptr)
        throw "no head value";
    else {
        inventory_node *curr = head;
        while (curr->upc != input_upc) {
            curr = curr->next;
        }
        stack find;
        find.operator=(curr -> price);
        int highPrice = find.top().value;
        find.pop();
        while (find.empty() == false) {
            if (find.top().value > highPrice)
                highPrice = find.top().value;
            find.pop();
        }
        return highPrice;
    }
}

void inventory::adjust_price(int input_upc, int new_price, int new_date) {
    if (valid_upc(input_upc) == false)
        throw "no input upc";
    else if (head == nullptr)
        throw "no head value";
    else {
        struct value_date input;
        input.value = new_price;
        input.date = new_date;
        inventory_node* curr = head;
        while (curr -> upc != input_upc) {
            curr = curr -> next;
        }
        curr -> price.push(input);
    }
}

void inventory::adjust_inventory(int input_upc, int new_inventory) {
    if (valid_upc(input_upc) == false)
        throw "no input upc";
    else if (head == nullptr)
        throw "no head value";
    else {
        inventory_node * curr = head;
        while (curr -> upc != input_upc) {
            curr = curr -> next;
        }
        curr -> inventory_count = new_inventory;
    }
}

void inventory::sort_by_lowest_price() {

}

inventory_node *inventory::get_head() {
    return head;
}
