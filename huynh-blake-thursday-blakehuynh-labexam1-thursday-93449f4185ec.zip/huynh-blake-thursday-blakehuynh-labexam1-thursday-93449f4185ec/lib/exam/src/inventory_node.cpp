#include "../inc/inventory_node.h"

inventory_node::inventory_node(int input_upc, std::string input_name, int input_count, int input_price, int date) {
    upc = input_upc;
    name = input_name;
    inventory_count = input_count;
    value_date values;
    values.value = input_price;
    values.date = date;
    price.push(values);
    next = nullptr;
}

inventory_node::~inventory_node()=default;

